package com.dicoding.mystoryapp.data.repository

import androidx.lifecycle.LiveData
import androidx.lifecycle.liveData
import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.PagingData
import androidx.paging.liveData
import com.dicoding.mystoryapp.data.pref.UserModel
import com.dicoding.mystoryapp.data.pref.UserPref
import com.dicoding.mystoryapp.data.response.ErrorResponse
import com.dicoding.mystoryapp.data.response.ListStory
import com.dicoding.mystoryapp.data.response.SignInResponse
import com.dicoding.mystoryapp.data.response.SignUpResponse
import com.dicoding.mystoryapp.data.response.Upload
import com.dicoding.mystoryapp.data.retrofit.ApiService
import com.google.gson.Gson
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import retrofit2.HttpException
import java.io.File

class UserRepository(
    private val apiService: ApiService,
    private val userPref: UserPref,
){
    companion object{
        private var INSTANCE: UserRepository? = null
        fun clearInstance(){
            INSTANCE = null
        }

        fun getInstance(
            apiService: ApiService,
            userPref: UserPref
        ): UserRepository =
            INSTANCE ?: synchronized(this){
                INSTANCE ?: UserRepository(apiService, userPref)
            }.also { INSTANCE = it }
    }

    private suspend fun getToken(): String{
        return userPref.getSession().first().token
    }

    fun getQuote(): LiveData<PagingData<ListStory>>{
        return  liveData {
            val token = getToken()
            val pager = Pager(
                config = PagingConfig(
                    pageSize = 5
                ),
                pagingSourceFactory = {
                    StoryPagingSrc(apiService, token)
                }
            )
            emitSource(pager.liveData)
        }
    }

    fun getStoriesLocal():
            LiveData<ResultState<List<ListStory>>> = liveData {
                emit(ResultState.Loading)
        try {
            val resp = apiService.getStoryLocal()
            emit(ResultState.Success(resp.listStory))
        } catch (e: HttpException){
            val errorBody = e.response()?.errorBody()?.string()
            val errorResp = Gson().fromJson(errorBody, ErrorResponse::class.java)
            emit(ResultState.Error(errorResp.message))
        }catch (e: Exception){
            emit(ResultState.Error(e.message ?: "Error"))
        }
    }

    fun loadImage(image: File, desc: String): LiveData<ResultState<Upload>> = liveData {
        emit(ResultState.Loading)
        val reqBody = desc.toRequestBody("text/plain".toMediaType())
        val reqImage = image.asRequestBody("image/jpeg".toMediaType())
        val multipartBody = MultipartBody.Part.createFormData(
            "photo",
            image.name,
            reqImage
        )
        try {
            val succesResp = apiService.uploadImage(multipartBody, reqBody)
            emit(ResultState.Success(succesResp))
        }catch (e: HttpException){
            val errorBody = e.response()?.errorBody()?.string()
            val errorResp = Gson().fromJson(errorBody, Upload::class.java)
            emit(ResultState.Error(errorResp.message))
        }
    }

    fun getStory(): LiveData<ResultState<List<ListStory>>> = liveData {
        emit(ResultState.Loading)
        try {
            val token = getToken()
            val resp = apiService.getStory("Bearer $token")
            emit(ResultState.Success(resp.listStory))
        }catch (e: HttpException){
            val errorBody = e.response()?.errorBody()?.string()
            val errorResp = Gson().fromJson(errorBody, ErrorResponse::class.java)
            emit(ResultState.Error(errorResp.message))
        }catch (e: Exception){
            emit(ResultState.Error(e.message ?: "Error"))
        }
    }

    fun login(email: String, password: String): LiveData<ResultState<SignInResponse>> = liveData {
        emit(ResultState.Loading)
        try {
            val resp = apiService.login(email, password)
            emit(ResultState.Success(resp))
        } catch (e: HttpException){
            val error = e.response()?.errorBody()?.string()
            val body = Gson().fromJson(error, ErrorResponse::class.java)
            emit(ResultState.Error(body.message))
        }
    }

    fun regist(name: String, email: String, password: String): LiveData<ResultState<SignUpResponse>> = liveData {
        emit(ResultState.Loading)
        try {
            val resp = apiService.register(name, email, password)
            emit(ResultState.Success(resp))
        } catch (e: HttpException){
            val error = e.response()?.errorBody()?.string()
            val body = Gson().fromJson(error, ErrorResponse::class.java)
            emit(ResultState.Error(body.message))
        }
    }

    suspend fun saveSession(userModel: UserModel){
        userPref.saveSession(userModel)
    }

    fun getSession(): Flow<UserModel>{
        return userPref.getSession()
    }

    suspend fun logout(){
        userPref.logout()
    }

}

sealed class ResultState<out R> private constructor() {
    data class Success<out T>(val data: T) : ResultState<T>()
    data class Error(val error: String): ResultState<Nothing>()
    data object Loading : ResultState<Nothing>()
}