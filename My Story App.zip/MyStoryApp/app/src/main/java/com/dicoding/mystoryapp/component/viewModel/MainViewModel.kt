package com.dicoding.mystoryapp.component.viewModel

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import androidx.paging.PagingData
import androidx.paging.cachedIn
import com.dicoding.mystoryapp.data.pref.UserModel
import com.dicoding.mystoryapp.data.repository.UserRepository
import com.dicoding.mystoryapp.data.response.ListStory

class MainViewModel (private val  repository: UserRepository): ViewModel() {
    fun getStory() = repository.getStory()

    val quote: LiveData<PagingData<ListStory>> = repository.getQuote().cachedIn(viewModelScope)

    suspend fun logout(){
        repository.logout()
    }

    fun getSession(): LiveData<UserModel>{
        return repository.getSession().asLiveData()
    }
}