package com.dicoding.mystoryapp.component.viewModel

import androidx.lifecycle.ViewModel
import com.dicoding.mystoryapp.data.repository.UserRepository

class SignUpViewModel(private val repo: UserRepository): ViewModel() {

    fun regis(name: String, email: String, pass: String) =
        repo.regist(name, email, pass)

}