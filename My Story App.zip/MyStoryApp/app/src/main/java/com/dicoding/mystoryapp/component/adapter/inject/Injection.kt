package com.dicoding.mystoryapp.component.adapter.inject

import android.content.Context
import com.dicoding.mystoryapp.data.pref.UserPref
import com.dicoding.mystoryapp.data.pref.dataStore
import com.dicoding.mystoryapp.data.repository.UserRepository
import com.dicoding.mystoryapp.data.retrofit.ApiConfig
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking

object Injection {
    fun provideRepo(context: Context): UserRepository{
        val pref = UserPref.getInstance(context.dataStore)
        val user = runBlocking { pref.getSession().first() }
        val apiService = ApiConfig.getApiService(user.token)
        return UserRepository.getInstance(apiService, pref)
    }
}