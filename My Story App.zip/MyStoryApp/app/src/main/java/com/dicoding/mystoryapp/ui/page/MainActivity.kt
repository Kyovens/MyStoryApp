package com.dicoding.mystoryapp.ui.page

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.dicoding.mystoryapp.R
import com.dicoding.mystoryapp.component.adapter.LoadingAdapter
import com.dicoding.mystoryapp.component.adapter.PostAdapter
import com.dicoding.mystoryapp.component.viewModel.MainViewModel
import com.dicoding.mystoryapp.component.viewModel.ViewModelFac
import com.dicoding.mystoryapp.data.repository.ResultState
import com.dicoding.mystoryapp.databinding.ActivityMainBinding
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val viewModel by viewModels<MainViewModel> {
        ViewModelFac.getInst(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        initBinding()
        fabUpload()
        listItem()
        session()

    }

    private fun initBinding(){
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }

    private fun fabUpload(){
        binding.fabUploadPost.setOnClickListener{
            startActivity(Intent(this, StoryActivity::class.java))
        }
    }

    private fun listItem(){
        val layoutManager = LinearLayoutManager(this)
        binding.listPost.layoutManager = layoutManager
        val itemDecor = DividerItemDecoration(this, layoutManager.orientation)
        binding.listPost.addItemDecoration(itemDecor)
    }

    private fun session(){
        viewModel.getSession().observe(this) {
            if (!it.isLogin) {
                val intent = Intent(this, BeforeLogin::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
                startActivity(intent)
                finish()
            } else {
                getData()
                setAction()
            }
        }
    }

   private fun getData(){
       val adapter = PostAdapter()
       binding.listPost.adapter = adapter.withLoadStateFooter(
           footer = LoadingAdapter{
               adapter.retry()
           }
       )
       viewModel.quote.observe(this) {
           adapter.submitData(lifecycle, it)
       }
   }

    private fun setAction(){
        lifecycleScope.launch {
            viewModel.getStory().observe(this@MainActivity){
                when(it){
                    is ResultState.Success->{
                        binding.progressBar.visibility = View.INVISIBLE
                    }

                    is ResultState.Loading ->{
                        binding.progressBar.visibility = View.VISIBLE
                    }
                    is ResultState.Error ->{
                        binding.progressBar.visibility = View.INVISIBLE
                        val error = it.error
                        Toast.makeText(this@MainActivity, error, Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId){
            R.id.logout->{
                lifecycleScope.launch {
                    viewModel.logout()
                    val intent = Intent(this@MainActivity, BeforeLogin::class.java)
                    startActivity(intent)
                    finish()
                }
            }
        }
            return super.onOptionsItemSelected(item)
    }
}