package com.dicoding.mystoryapp.component.adapter

import android.app.Activity
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.app.ActivityOptionsCompat
import androidx.paging.PagingDataAdapter
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.dicoding.mystoryapp.data.response.ListStory
import com.dicoding.mystoryapp.databinding.ListItemReviewBinding
import com.dicoding.mystoryapp.ui.page.Detail

class PostAdapter : PagingDataAdapter<ListStory, PostAdapter.MyViewHolder>(DIFF_CALLBACK){

    companion object{
        val DIFF_CALLBACK = object : DiffUtil.ItemCallback<ListStory>(){
            override fun areContentsTheSame(oldItem: ListStory, newItem: ListStory): Boolean {
                return  oldItem == newItem
            }

            override fun areItemsTheSame(oldItem: ListStory, newItem: ListStory): Boolean {
                return oldItem == newItem
            }
        }
    }

    class MyViewHolder(private val binding: ListItemReviewBinding) : RecyclerView.ViewHolder(binding.root){
        fun bind(item: ListStory){
            binding?.apply {
                usernamePost.text = item.name
                descPost.text = item.description
                imgPost.setOnClickListener{
                    val intent = Intent(imgPost.context, Detail::class.java)
                    intent.putExtra(Detail.DETAIL, item)
                    itemView.context.startActivity(intent, ActivityOptionsCompat.makeSceneTransitionAnimation(itemView.context as Activity).toBundle())
                }
            }
        }
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val review = getItem(position)
        if (review != null){
            holder.bind(review)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val binding = ListItemReviewBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MyViewHolder(binding)
    }

}