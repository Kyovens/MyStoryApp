package com.dicoding.mystoryapp.component.viewModel

import androidx.lifecycle.ViewModel
import com.dicoding.mystoryapp.data.pref.UserModel
import com.dicoding.mystoryapp.data.repository.UserRepository

class SignInViewModel(private val repository: UserRepository): ViewModel() {

    fun login(email: String, pass: String) =
        repository.login(email, pass)

    suspend fun saveSession(userModel: UserModel){
        repository.saveSession(userModel)
    }
}