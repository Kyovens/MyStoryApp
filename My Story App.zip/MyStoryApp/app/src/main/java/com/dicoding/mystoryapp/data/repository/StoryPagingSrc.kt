package com.dicoding.mystoryapp.data.repository

import androidx.paging.PagingSource
import androidx.paging.PagingState
import com.dicoding.mystoryapp.data.response.ListStory
import com.dicoding.mystoryapp.data.retrofit.ApiService

class StoryPagingSrc(
    private val apiService: ApiService,
    private val token: String): PagingSource<Int, ListStory>() {

    private companion object{
        const val INITIAL_PAGE = 1
    }

    override suspend fun load(params: LoadParams<Int>): LoadResult<Int, ListStory> {
        return try {
            val position = params.key?: INITIAL_PAGE
            val resBody = apiService.getStory(
                "Bearer $token",
                position,
                params.loadSize,
            )
            LoadResult.Page(
                data = resBody.listStory,
                prevKey = if( position ==
                    INITIAL_PAGE) null else position - 1,
                nextKey = if (resBody.listStory.isEmpty()) null else position + 1
            )
        } catch ( exception: Exception ){
            return  LoadResult.Error(exception)
        }
    }

    override fun getRefreshKey(state: PagingState<Int, ListStory>): Int? {
        return state.anchorPosition?.let {
            val anchorPage = state.closestPageToPosition(it)
            anchorPage?.prevKey?.plus(1) ?: anchorPage?.nextKey?.minus(1)
        }
    }
}