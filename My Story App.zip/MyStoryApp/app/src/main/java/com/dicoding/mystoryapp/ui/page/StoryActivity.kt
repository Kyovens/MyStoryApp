package com.dicoding.mystoryapp.ui.page


import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.activity.result.PickVisualMediaRequest
import androidx.core.net.toUri
import com.dicoding.mystoryapp.R
import com.dicoding.mystoryapp.component.viewModel.StoryViewModel
import com.dicoding.mystoryapp.component.viewModel.ViewModelFac
import com.dicoding.mystoryapp.data.repository.ResultState
import com.dicoding.mystoryapp.databinding.ActivityStoryBinding
import com.dicoding.mystoryapp.ui.component.CameraxActivity
import com.dicoding.mystoryapp.ui.component.CameraxActivity.Companion.CAMERAX_RESULT
import com.dicoding.mystoryapp.ui.component.getImgUri
import com.dicoding.mystoryapp.ui.component.reduceFileImg
import com.dicoding.mystoryapp.ui.component.uriToFile

class StoryActivity : AppCompatActivity() {

    private lateinit var binding: ActivityStoryBinding
    private var currentImgUri: Uri? = null
    private val viewModel by viewModels<StoryViewModel> {
        ViewModelFac.getInst(this)
    }

    companion object{
        private const val REQUIRED_PERMISSION = Manifest.permission.CAMERA
    }

    private val reqPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ){ isGranted: Boolean ->
        if (isGranted){
            Toast.makeText(this, "Permission reques granted", Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(this, "Permission request denied", Toast.LENGTH_LONG).show()
        }
    }

    private fun allPermisiion() = ContextCompat.checkSelfPermission(
        this, REQUIRED_PERMISSION
    ) == PackageManager.PERMISSION_GRANTED

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        initBinding()

        if (!allPermisiion()){
            reqPermission.launch(REQUIRED_PERMISSION)
        }

        binding.apply {
            galleryBtn.setOnClickListener{ startGalerry() }
            cameraBtn.setOnClickListener { startCamera() }
            cameraXBtn.setOnClickListener { startCameraX() }
            uploadBtn.setOnClickListener { startUpload() }
        }
    }

    private fun initBinding(){
        binding = ActivityStoryBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }

    private fun startGalerry(){
        launchGallery.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
    }

    private val launchGallery = registerForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ){
        if (it != null){
            currentImgUri = it
            showImage()
        } else{
            Log.d("Photo Picker", "No media selected")
        }
    }

    private fun showImage(){
        val uri = currentImgUri
        if (uri != null){
            Log.d("Image URI", "showImg: $uri")
            binding.imageView.setImageURI(uri)
        }
    }

    private fun startCamera(){
        currentImgUri = getImgUri(this)
        launchIntentCamera.launch(currentImgUri!!)
    }

    private val launchIntentCamera = registerForActivityResult(
        ActivityResultContracts.TakePicture()
    ){isSucces->
        if(isSucces){
            showImage()
        }
    }

    private fun startCameraX(){
        val intent = Intent(this, CameraxActivity::class.java)
        launchIntentCameraX.launch(intent)
    }

    private val launchIntentCameraX = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ){
        if(it.resultCode == CAMERAX_RESULT){
            currentImgUri = it.data?.getStringExtra(
                CameraxActivity.EXTRA_CAMERAX_IMAGE
            )?.toUri()
            showImage()
        }
    }

    private fun startUpload(){
        currentImgUri?.let {
            val imgFile = uriToFile(it, this).reduceFileImg()
            Log.d("Image File", "showImage: ${imgFile.path}")
            val desc = binding.edtTxtDesc.text.toString()

            viewModel.uploadImg(imgFile, desc).observe(this){res->
                when(res){
                    is ResultState.Loading ->{
                        showLoad(true)
                    }
                    is ResultState.Success ->{
                        showToast(res.data.message)
                        showLoad(false)
                        showMain()
                    }
                    is ResultState.Error -> {
                        showToast(res.error)
                        showLoad(false)
                    }
                }
            }
        } ?: showToast(getString(R.string.emptyImage))
    }

    private fun showLoad(isLoad: Boolean){
        binding.progressBar.visibility = if (isLoad) View.VISIBLE else View.GONE
    }

    private fun showMain(){
        val intent = Intent(this, MainActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
        startActivity(intent)
        finish()
    }

    private fun showToast(msg: String){
        Toast.makeText(this,msg, Toast.LENGTH_SHORT).show()
    }
}