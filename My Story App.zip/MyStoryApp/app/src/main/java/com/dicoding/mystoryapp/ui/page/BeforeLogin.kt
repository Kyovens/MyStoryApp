package com.dicoding.mystoryapp.ui.page

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowInsets
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import com.dicoding.mystoryapp.databinding.ActivityBeforeLoginBinding
import com.dicoding.mystoryapp.ui.signIn.SignInActivity
import com.dicoding.mystoryapp.ui.singUp.SignUpActivity

class BeforeLogin : AppCompatActivity() {
    private lateinit var binding: ActivityBeforeLoginBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBeforeLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)
//        viewBinding()
        intentAction()
//        setView()
        animation()
    }

//    private fun viewBinding(){
//        binding = ActivityBeforeLoginBinding.inflate(layoutInflater)
//        setContentView(binding.root)
//    }

    private fun intentAction(){
        binding.loginBtn.setOnClickListener{
            startActivity(Intent(this, SignInActivity::class.java))
        }
        binding.signUpBtn.setOnClickListener{
            startActivity(Intent(this, SignUpActivity::class.java))
        }
    }
//    @Suppress("DEPRECATION")
//    private fun setView(){
//        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.R){
//            window.insetsController?.hide(WindowInsets.Type.statusBars())
//        } else {
//            window.setFlags(
//                WindowManager.LayoutParams.FLAG_FULLSCREEN,
//                WindowManager.LayoutParams.FLAG_FULLSCREEN
//            )
//        }
//        supportActionBar?.hide()
//    }

    private fun animation(){
        ObjectAnimator.ofFloat(binding.gbLogin, View.TRANSLATION_X, -30f, 30f).apply {
            duration = 6000
            repeatCount = ObjectAnimator.INFINITE
            repeatMode = ObjectAnimator.REVERSE
        }.start()

        val signIn = ObjectAnimator.ofFloat(binding.loginBtn, View.ALPHA, 1f).setDuration(100)
        val signUp = ObjectAnimator.ofFloat(binding.signUpBtn, View.ALPHA, 1f).setDuration(100)
        val title = ObjectAnimator.ofFloat(binding.title, View.ALPHA, 1f).setDuration(100)
        val descMenu = ObjectAnimator.ofFloat(binding.desc, View.ALPHA, 1f).setDuration(100)

        val gather = AnimatorSet().apply {
            playTogether(signIn, signUp)
        }

        AnimatorSet().apply {
            playSequentially(title, descMenu, gather)
        }.start()
    }
}