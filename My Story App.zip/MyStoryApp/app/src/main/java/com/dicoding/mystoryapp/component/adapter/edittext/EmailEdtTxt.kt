package com.dicoding.mystoryapp.component.adapter.edittext

import android.content.Context
import android.text.Editable
import android.text.TextWatcher
import android.util.AttributeSet
import android.util.Patterns
import androidx.appcompat.widget.AppCompatEditText

class EmailEdtTxt : AppCompatEditText {
    constructor(context: Context): super(context){
        init()
    }

    constructor(context: Context, attr: AttributeSet) : super(context, attr){
        init()
    }

    constructor(context: Context, attr: AttributeSet, defStyle: Int) : super(context, attr, defStyle){
        init()
    }

    private fun init(){
        addTextChangedListener(object : TextWatcher{
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                error = if (!Patterns.EMAIL_ADDRESS.matcher(s).matches()){
                    "Input correct email!"
                } else{
                    null
                }
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun afterTextChanged(s: Editable?) {
            }
        })
    }
}

class EdtText : AppCompatEditText{
    constructor(context: Context): super(context){
        init()
    }

    constructor(context: Context, attr: AttributeSet): super(context, attr){
        init()
    }

    constructor(context: Context, attr: AttributeSet, defStyle: Int): super(context, attr, defStyle){
        init()
    }

    private fun init(){
        addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                error = if (s.toString().length < 8){
                    "Length Password must be more 8 characters"
                } else{
                    null
                }
            }

            override fun afterTextChanged(s: Editable?) {
            }
        })
    }
}