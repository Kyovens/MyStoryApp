package com.dicoding.mystoryapp.component.viewModel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.dicoding.mystoryapp.component.adapter.inject.Injection
import com.dicoding.mystoryapp.data.repository.UserRepository
import java.lang.IllegalArgumentException

@Suppress("UNCHECKED_CAST")
class ViewModelFac(private val repository: UserRepository):
    ViewModelProvider.NewInstanceFactory() {

    companion object{
        private var INSTANCE: ViewModelFac? = null

        fun clearInst(){
            UserRepository.clearInstance()
            INSTANCE = null
        }

        fun getInst(context: Context): ViewModelFac{
            if (INSTANCE == null){
                synchronized(ViewModelFac::class.java){
                    INSTANCE = ViewModelFac(Injection.provideRepo(context))
                }
            }
            return INSTANCE as ViewModelFac
        }
    }

    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return when{
            modelClass.isAssignableFrom(SignUpViewModel::class.java) -> {
                SignUpViewModel(repository) as T
            }
            modelClass.isAssignableFrom(SignInViewModel::class.java)->{
                SignInViewModel(repository) as T
            }
            modelClass.isAssignableFrom(MainViewModel::class.java)->{
                MainViewModel(repository) as T
            }

            modelClass.isAssignableFrom(StoryViewModel::class.java)->{
                StoryViewModel(repository) as T
            }

            else -> throw  IllegalArgumentException("Unkown ViewModel class: " + modelClass.name)
        }
    }
}