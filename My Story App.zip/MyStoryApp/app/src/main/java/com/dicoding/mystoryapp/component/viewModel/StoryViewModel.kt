package com.dicoding.mystoryapp.component.viewModel

import androidx.lifecycle.ViewModel
import com.dicoding.mystoryapp.data.repository.UserRepository
import java.io.File

class StoryViewModel (private val repository: UserRepository) : ViewModel(){
    fun uploadImg(file: File, desc: String) = repository.loadImage(file, desc)
}