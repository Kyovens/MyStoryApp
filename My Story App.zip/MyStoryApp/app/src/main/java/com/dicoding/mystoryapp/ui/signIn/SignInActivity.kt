package com.dicoding.mystoryapp.ui.signIn

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.WindowInsets
import android.view.WindowManager
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.dicoding.mystoryapp.component.adapter.edittext.EdtText
import com.dicoding.mystoryapp.component.adapter.edittext.EmailEdtTxt
import com.dicoding.mystoryapp.component.viewModel.SignInViewModel
import com.dicoding.mystoryapp.component.viewModel.ViewModelFac
import com.dicoding.mystoryapp.data.pref.UserModel
import com.dicoding.mystoryapp.data.repository.ResultState
import com.dicoding.mystoryapp.databinding.ActivitySignInBinding
import com.dicoding.mystoryapp.ui.page.MainActivity
import kotlinx.coroutines.launch

class SignInActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySignInBinding
    private lateinit var emailEdt: EmailEdtTxt
    private lateinit var edtTxt: EdtText
    private val viewModel by viewModels<SignInViewModel> {
        ViewModelFac.getInst(this)
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        initBinding()
        edtText()
        animation()
        setView()
        setAction()
    }

    private fun initBinding(){
        binding = ActivitySignInBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }

    private fun edtText(){
        emailEdt = binding.emailEdtTxt
        edtTxt = binding.pwEdtTxt

    }


    private fun animation(){
        ObjectAnimator.ofFloat(binding.imageView, View.TRANSLATION_X, -30f, 30f).apply {
            duration = 6000
            repeatCount = ObjectAnimator.INFINITE
            repeatMode = ObjectAnimator.REVERSE
        }.start()

        val title = ObjectAnimator.ofFloat(binding.titlePage, View.ALPHA, 1f).setDuration(100)
        val msg = ObjectAnimator.ofFloat(binding.msgPage, View.ALPHA, 1f).setDuration(100)
        val email = ObjectAnimator.ofFloat(binding.emailEdtTxtLayout, View.ALPHA, 1f).setDuration(100)
        val pass = ObjectAnimator.ofFloat(binding.pwEdtTxtLayout, View.ALPHA, 1f).setDuration(100)
        val forgetPw = ObjectAnimator.ofFloat(binding.forgetPw, View.ALPHA, 1f).setDuration(100)
        val btn = ObjectAnimator.ofFloat(binding.loginBtn, View.ALPHA, 1f).setDuration(100)

        AnimatorSet().apply {
            playSequentially(
                title,
                msg,
                email,
                pass,
                forgetPw,
                btn
            )
            startDelay = 100
        }.start()
    }

    @Suppress("DEPRECATION")
    private fun setView(){
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.R){
            window.insetsController?.hide(WindowInsets.Type.statusBars())
        } else {
            window.setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN
            )
        }
        supportActionBar?.hide()
    }

    private fun setAction(){
        binding.loginBtn.setOnClickListener{
            val email = binding.emailEdtTxt.text.toString()
            val pass = binding.pwEdtTxt.text.toString()

            viewModel.login(email, pass).observe(this){
                when(it){
                    is ResultState.Loading ->{
                        binding.progressBar.visibility = View.VISIBLE
                    }

                    is ResultState.Success ->{
                        binding.progressBar.visibility = View.INVISIBLE
                        AlertDialog.Builder(this).apply {
                            setTitle("Successful")
                            setMessage("You have logged in successfully")
                            setPositiveButton("Continue"){_, _ ->
                                saveSession(
                                    UserModel(
                                        it.data.loginResult.token,
                                        it.data.loginResult.name,
                                        it.data.loginResult.userId,
                                        true
                                    )
                                )
                            }
                            Log.e("Login", it.data.loginResult.token)
                            create()
                            show()
                        }
                    }

                    is ResultState.Error ->{
                        binding.progressBar.visibility = View.INVISIBLE
                        AlertDialog.Builder(this).apply {
                            setTitle("Wrong!")
                            setMessage("Wrong email or password!")
                            setPositiveButton("Back"){dialog, _ ->
                                dialog.dismiss()
                            }
                        }.create().show()
                    }
                }
            }
        }
    }

    private fun saveSession(session: UserModel){
        lifecycleScope.launch {
            viewModel.saveSession(session)
            val intent = Intent(this@SignInActivity, MainActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
            ViewModelFac.clearInst()
            startActivity(intent)
        }
    }
}