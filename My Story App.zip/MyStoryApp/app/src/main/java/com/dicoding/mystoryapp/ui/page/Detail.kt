package com.dicoding.mystoryapp.ui.page

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.dicoding.mystoryapp.data.response.ListStory
import com.dicoding.mystoryapp.databinding.ActivityDetailBinding

@Suppress("DEPRECATION")
class Detail : AppCompatActivity() {
    private lateinit var binding: ActivityDetailBinding

    companion object{
        const val DETAIL = "detail"
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        initBinding()
        val detail = intent.getParcelableExtra<ListStory>(DETAIL) as ListStory
        setAction(detail)

    }

    private fun initBinding(){
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }



    private fun setAction(detail: ListStory){
        Glide.with(applicationContext)
            .load(detail.photoUrl)
            .into(binding.detailUserImage)
        binding.apply {
            name.text = detail.name
            desc.text = detail.description
        }
    }
}